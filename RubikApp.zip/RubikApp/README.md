# Rubik Trainer (Android)

Kerangka aplikasi Android (Kotlin + Jetpack Compose) untuk latihan kubus Rubik 3x3.

## Isi
- **Acak**: pembuat acakan 20 gerakan tanpa pola berulang yang tidak perlu.
- **Rumus**: daftar rumus CFOP (F2L, OLL, PLL) dan Roux, dikelompokkan per metode dan tahap.
- **Warna**: input warna 6 sisi x 9 stiker (ketuk untuk ganti warna).

## Yang belum ada
- Mesin penyelesaian dari input warna (solver) dan panduan gerakan langkah demi langkah.
- Cross, advanced cross, F2L lengkap, 1LL, dan rumus Roux lanjutan belum dimasukkan.

## Cara build APK
1. Pasang Android Studio (Ladybug atau lebih baru).
2. Buka Android Studio > Open > pilih folder `RubikApp`.
3. Tunggu Gradle sync selesai.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.
