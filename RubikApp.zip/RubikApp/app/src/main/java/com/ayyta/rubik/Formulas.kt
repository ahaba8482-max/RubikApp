package com.ayyta.rubik

/** Satu entri rumus: nama, metode, tahap, dan notasi gerakan. */
data class Formula(
    val name: String,
    val method: String,
    val stage: String,
    val notation: String,
    val note: String = ""
)

object Formulas {

    val all: List<Formula> = listOf(
        // ---- CFOP: F2L (insert pasangan sudut-tepi) ----
        Formula("Right insert", "CFOP", "F2L", "U R U' R'", "Pasangan di kanan, sudut sudah di atas"),

        // ---- OLL (orientasi sisi atas) ----
        Formula("Sune", "CFOP", "OLL", "R U R' U R U2 R'", "Satu sudut sudah terorientasi"),
        Formula("Antisune", "CFOP", "OLL", "R U2 R' U' R U' R'", "Pola kebalikan dari Sune"),

        // ---- PLL (permutasi lapisan atas) ----
        Formula("T-perm", "CFOP", "PLL", "R U R' U' R' F R2 U' R' U' R U R' F'", "Tukar dua tepi dan dua sudut"),
        Formula("Y-perm", "CFOP", "PLL", "F R U' R' U' R U R' F' R U R' U' R' F R F'", "Tukar pasangan diagonal"),
        Formula("Ua-perm", "CFOP", "PLL", "R U' R U R U R U' R' U' R2", "Memutar tiga tepi"),
        Formula("Jb-perm", "CFOP", "PLL", "R U R' F' R U R' U' R' F R2 U' R'", "Tukar dua tepi dan dua sudut"),

        // ---- Roux ----
        Formula("Sexy move", "Roux", "Dasar", "R U R' U'", "Gerakan dasar, sering diulang"),
        Formula("Sledgehammer", "Roux", "Dasar", "R' F R F'", "Gerakan dasar Roux untuk blok kedua"),

        // ---- Gerakan dasar lain ----
        Formula("Sexy move (kiri)", "Umum", "Dasar", "L' U' L U", "Versi cermin dari Sexy move")
    )

    /** Mengelompokkan rumus berdasarkan metode, lalu tahap. */
    fun grouped(): Map<String, Map<String, List<Formula>>> =
        all.groupBy { it.method }.mapValues { (_, list) -> list.groupBy { it.stage } }
}
