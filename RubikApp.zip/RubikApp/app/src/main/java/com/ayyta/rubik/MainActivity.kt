package com.ayyta.rubik

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    RubikHome()
                }
            }
        }
    }
}

private val tabs = listOf("Acak", "Rumus", "Warna")

@Composable
fun RubikHome() {
    var selected by remember { mutableStateOf(0) }
    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selected) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selected == index,
                    onClick = { selected = index },
                    text = { Text(title) }
                )
            }
        }
        when (selected) {
            0 -> ScrambleScreen()
            1 -> FormulaScreen()
            2 -> ColorInputScreen()
        }
    }
}

@Composable
fun ScrambleScreen() {
    var scramble by remember { mutableStateOf(Scramble.generate()) }
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Acakan", style = MaterialTheme.typography.titleLarge)
        Text(scramble, style = MaterialTheme.typography.bodyLarge)
        Button(onClick = { scramble = Scramble.generate() }) {
            Text("Acak baru")
        }
    }
}

@Composable
fun FormulaScreen() {
    val grouped = remember { Formulas.grouped() }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        grouped.forEach { (method, stages) ->
            item { Text(method, style = MaterialTheme.typography.titleLarge) }
            stages.forEach { (stage, list) ->
                item { Text(stage, style = MaterialTheme.typography.titleMedium) }
                items(list) { f ->
                    Column(modifier = Modifier.padding(bottom = 8.dp)) {
                        Text(f.name, style = MaterialTheme.typography.bodyLarge)
                        Text(f.notation, style = MaterialTheme.typography.bodyMedium)
                        if (f.note.isNotEmpty()) {
                            Text(f.note, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

// Warna stiker: urutan siklus saat diketuk.
private val stickerColors = listOf(
    Color.White, Color.Yellow, Color.Red, Color.Blue, Color(0xFFFF8C00), Color(0xFF00C853)
)

private val faceNames = listOf("U (atas)", "D (bawah)", "L (kiri)", "R (kanan)", "F (depan)", "B (belakang)")

@Composable
fun ColorInputScreen() {
    // 6 sisi x 9 stiker, default putih semua.
    val stickers = remember { mutableStateListOf(*Array(54) { 0 }) }
    Column(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Ketuk stiker untuk ganti warna", style = MaterialTheme.typography.bodyMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(6) { face ->
                Text(faceNames[face], style = MaterialTheme.typography.titleSmall)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (row in 0 until 3) {
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            for (col in 0 until 3) {
                                val idx = face * 9 + row * 3 + col
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(
                                            stickerColors[stickers[idx]],
                                            RoundedCornerShape(4.dp)
                                        )
                                        .clickable {
                                            stickers[idx] = (stickers[idx] + 1) % stickerColors.size
                                        },
                                    contentAlignment = Alignment.Center
                                ) {}
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.size(4.dp))
        // Mesin penyelesaian (solver) belum disertakan di build ini.
        Text(
            "Penyelesaian langkah demi langkah belum aktif di build ini.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
