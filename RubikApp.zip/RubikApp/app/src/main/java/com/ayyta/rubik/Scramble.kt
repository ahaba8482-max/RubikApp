package com.ayyta.rubik

import kotlin.random.Random

/**
 * Pembuat acakan (scramble) untuk kubus 3x3.
 * Aturan: tidak ada dua gerakan berurutan pada sisi yang sama,
 * dan sisi berhadapan tidak boleh muncul berulang (misal R L R).
 */
object Scramble {

    private val faces = listOf("U", "D", "L", "R", "F", "B")
    private val modifiers = listOf("", "'", "2")

    // Pasangan sisi berhadapan, dipakai untuk mencegah pola redundan.
    private val opposite = mapOf(
        "U" to "D", "D" to "U",
        "L" to "R", "R" to "L",
        "F" to "B", "B" to "F"
    )

    fun generate(length: Int = 20, random: Random = Random.Default): String {
        val moves = mutableListOf<String>()
        var lastFace: String? = null
        var lastBeforeFace: String? = null

        while (moves.size < length) {
            val face = faces.random(random)
            if (face == lastFace) continue
            // Cegah pola X Y X dengan Y berhadapan X (contoh: R L R).
            if (face == lastBeforeFace && opposite[lastFace] == face) continue

            moves.add(face + modifiers.random(random))
            lastBeforeFace = lastFace
            lastFace = face
        }
        return moves.joinToString(" ")
    }
}
